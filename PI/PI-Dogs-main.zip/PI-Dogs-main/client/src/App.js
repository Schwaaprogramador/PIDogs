import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Henry Dogs</h1>
    </div>
  );
}

export default App;
